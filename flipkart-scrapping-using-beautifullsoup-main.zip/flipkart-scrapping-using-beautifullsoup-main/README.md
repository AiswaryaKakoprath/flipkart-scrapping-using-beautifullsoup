# flipkart-scrapping-using-beautifullsoup
here we are webscrapping data from flipkart and changing it into csv files
